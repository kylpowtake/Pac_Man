package Comportement;

public enum EnumComportement {
	//comportement aléatoires 
	PACMAN_RANDOM,
	FANTOME_RANDOM,
	
	//comportements normaux  
	PACMAN_FACILE,
	FANTOME_FACILE,
	
	
	//comportements algorithme A* (à implémenter) 
	PACMAN_ALGO,
	FANTOME_ALGO
}
