package Comportement;
import model.*;
public class ComportementPacmanAlgo extends ComportementPacman {

	@Override
	public void comportementFuite(Agent agent, Game game) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void comportementNormal(Agent agent, Game game) {
		// TODO Auto-generated method stub
		
	}

}
