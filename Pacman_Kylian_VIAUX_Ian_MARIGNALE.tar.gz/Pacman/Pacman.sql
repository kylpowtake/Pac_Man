-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le :  lun. 08 avr. 2019 à 11:14
-- Version du serveur :  10.1.35-MariaDB
-- Version de PHP :  7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `Pacman`
--

-- --------------------------------------------------------

--
-- Structure de la table `Partie`
--

CREATE TABLE `Partie` (
  `id` int(11) NOT NULL,
  `idUtilisateur` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `fantomesManges` int(11) NOT NULL,
  `capsulesMangees` int(11) NOT NULL,
  `pacGommesMangees` int(11) NOT NULL,
  `mapsEffectuees` int(11) NOT NULL,
  `pasEffectues` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Déchargement des données de la table `Partie`
--

INSERT INTO `Partie` (`id`, `idUtilisateur`, `score`, `fantomesManges`, `capsulesMangees`, `pacGommesMangees`, `mapsEffectuees`, `pasEffectues`, `date`) VALUES
(71, 1, 828, 1, 8, 778, 11, 2578, '2019-04-02 15:47:32'),
(72, 1, 0, 0, 0, 0, 0, 6, '2019-04-02 15:47:48'),
(73, 1, 0, 0, 0, 0, 0, 1, '2019-04-02 15:47:55'),
(74, 2, 1081, 4, 16, 961, 13, 2542, '2019-04-02 15:48:51'),
(75, 2, 0, 0, 0, 0, 0, 1, '2019-04-02 15:50:37'),
(76, 2, 511, 0, 4, 491, 8, 2268, '2019-04-02 15:54:40'),
(77, 2, 0, 0, 0, 0, 0, 125, '2019-04-02 16:02:12'),
(78, 2, 0, 0, 0, 0, 0, 26, '2019-04-02 16:02:29'),
(79, 2, 0, 0, 0, 0, 0, 0, '2019-04-02 16:02:35'),
(80, 2, 23, 0, 0, 23, 0, 67, '2019-04-02 16:02:43'),
(81, 2, 795, 0, 0, 795, 15, 3287, '2019-04-02 16:09:01'),
(82, 2, 0, 0, 0, 0, 0, 1, '2019-04-02 16:09:13'),
(83, 2, 502, 4, 9, 417, 7, 1204, '2019-04-02 16:11:15'),
(84, 2, 0, 0, 0, 0, 0, 1, '2019-04-02 16:11:37'),
(85, 2, 0, 0, 0, 0, 0, 0, '2019-04-02 16:11:41'),
(86, 2, 145, 4, 8, 65, 1, 315, '2019-04-02 16:12:15'),
(87, 2, 0, 0, 0, 0, 0, 1, '2019-04-02 16:12:28'),
(88, 2, 0, 0, 0, 0, 0, 0, '2019-04-02 16:12:31'),
(89, 2, 0, 0, 0, 0, 0, 0, '2019-04-02 16:12:38'),
(90, 2, 0, 0, 0, 0, 0, 25, '2019-04-02 16:13:31'),
(91, 2, 0, 0, 0, 0, 0, 0, '2019-04-02 16:14:06'),
(92, 2, 0, 0, 0, 0, 0, 0, '2019-04-02 16:14:26'),
(93, 2, 0, 0, 0, 0, 0, 0, '2019-04-02 16:14:34'),
(94, 2, 0, 0, 0, 0, 0, 0, '2019-04-02 16:14:40'),
(95, 2, 15, 0, 0, 15, 2, 166, '2019-04-02 16:15:09'),
(96, 2, 0, 0, 0, 0, 0, 1, '2019-04-02 16:15:28'),
(97, 1, 1422, 2, 13, 1337, 27, 4050, '2019-04-02 16:15:56'),
(98, 2, 221, 0, 0, 221, 1, 672, '2019-04-02 16:16:40'),
(99, 1, 30, 0, 0, 30, 4, 308, '2019-04-02 16:18:11'),
(100, 1, 0, 0, 0, 0, 0, 1, '2019-04-02 16:18:32'),
(101, 2, 372, 3, 6, 312, 7, 1138, '2019-04-02 16:19:03');

-- --------------------------------------------------------

--
-- Structure de la table `Utilisateur`
--

CREATE TABLE `Utilisateur` (
  `id` int(11) NOT NULL,
  `pseudo` varchar(30) COLLATE utf32_bin NOT NULL,
  `mot_de_passe` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `date_inscription` datetime NOT NULL,
  `activite` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Déchargement des données de la table `Utilisateur`
--

INSERT INTO `Utilisateur` (`id`, `pseudo`, `mot_de_passe`, `date_inscription`, `activite`) VALUES
(1, 'BestOKyl', 'YQL1K7w4JhZ01t0TENyjuEADpW/n30g+zw8PGWpcjPg4MaZVUCxTiQ==', '2019-04-02 15:32:57', 1),
(2, 'BestPlayerEU', 'w8cCqy7rkRsSDB+phQVhloy8N99Pn8j8B5rE+M7eQxtIwOY5lEgoEA==', '2019-04-02 15:33:29', 1);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `Partie`
--
ALTER TABLE `Partie`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_utilisateur` (`idUtilisateur`);

--
-- Index pour la table `Utilisateur`
--
ALTER TABLE `Utilisateur`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `Partie`
--
ALTER TABLE `Partie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `Partie`
--
ALTER TABLE `Partie`
  ADD CONSTRAINT `Partie_ibfk_1` FOREIGN KEY (`idUtilisateur`) REFERENCES `Utilisateur` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
